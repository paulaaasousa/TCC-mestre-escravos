#pragma once
#include <Arduino.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>

// Set your Board and Server ID
#define BOARD_ID 2
#define CHANNEL 5

const int ledPin = 32;
const int sensorPin = 33;  // Pino do sensor infravermelho (deve s1er um pino que suporta interrupções)

int rotina_34;
unsigned long startTime = 0;

uint8_t My_Address[] = {0xA4, 0xE5, 0x7C, 0x47, 0x15, 0x94};
uint8_t Master_Address[] = {0x08, 0x3A, 0xF2, 0x66, 0xB9, 0xD8};

int recebido;

esp_err_t result;

// Strutura para envio das mensagens
typedef struct message_
{
  uint8_t id = 0xFF;
  int Status_Led = 0;
  int rotina = 0;
} message_;
message_ myData;

bool addPeer(const uint8_t *mac_addr, uint8_t chan);
void printMAC(const uint8_t *mac_addr);
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status);
void OnDataRecv(const uint8_t *mac_addr, const uint8_t *incomingData, int len);
bool init_esp_now();

// Função usada para adicionar os Mestre/Slaves
bool addPeer(const uint8_t *mac_addr, uint8_t chan)
{
  esp_now_peer_info_t peer;
  esp_now_del_peer(mac_addr);
  memset(&peer, 0, sizeof(esp_now_peer_info_t));
  peer.channel = chan;
  peer.encrypt = false;
  memcpy(peer.peer_addr, mac_addr, sizeof(uint8_t[6]));
  if (esp_now_add_peer(&peer) != ESP_OK)
  {
    Serial.print("Failed to add peer: ");
    printMAC(mac_addr);
    return false;
  }
  return true;
}

// Bem..... isso da print no Mac..... meio óbvio
void printMAC(const uint8_t *mac_addr)
{
  char macStr[18];
  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x",
           mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
  Serial.print(macStr);
}

// Call Back do envio da mensagem
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status)
{
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

void rotina(void)
{
  digitalWrite(ledPin, HIGH);
  Serial.println("Aguardando botao.");
  while (digitalRead(sensorPin) == 1) // aguarda o botão ser pressionado
  {
    if (rotina_34 == 1 && (millis() - startTime >= 5000))
    {
      Serial.println("Tempo esgotado!");
      break;
    }
    else if (rotina_34 == 2 && (millis() - startTime >= 3000))
    {
      Serial.println("Tempo esgotado!");
      break;
    }
    vTaskDelay(1);
  }
  vTaskDelay(50);
  digitalWrite(ledPin, LOW);
  myData.Status_Led = 22;
  vTaskDelay(200);
  result = esp_now_send(Master_Address, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
  if (result == ESP_OK)
    Serial.println("Sent with success to Master");
  else
    Serial.println("Error sending the data to Master");
  myData.Status_Led = 0;
}

// Call Back da recepção da mensagem
void OnDataRecv(const uint8_t *mac_addr, const uint8_t *incomingData, int len)
{
  Serial.print("Packet received from: ");
  printMAC(mac_addr);
  Serial.println();
  Serial.print("data size = ");
  Serial.print(sizeof(incomingData));
  Serial.print(", len = ");
  Serial.println(len);
  memcpy(&myData, incomingData, sizeof(myData));
  Serial.println(" ");
  Serial.printf("ID: %d, LED: %d /n", myData.id, myData.Status_Led);
  rotina_34 = myData.rotina;
  Serial.println(myData.rotina);
  startTime = millis();
  rotina();
}

// Iniciar o Esp Now
bool init_esp_now()
{
  WiFi.mode(WIFI_STA);

  pinMode(sensorPin, INPUT); // Configura o pino do sensor como entrada com pull-up interno
  pinMode(ledPin, OUTPUT);          // Configuração dos LEDs como saídas
  digitalWrite(ledPin, LOW);        // Desliga todos os LEDs inicialmente

  // set WiFi channel
  ESP_ERROR_CHECK(esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE));
  if (esp_now_init() != ESP_OK)
  {
    Serial.println("Error initializing ESP-NOW");
    return false;
  }

  // set callback routines
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  return true;
}