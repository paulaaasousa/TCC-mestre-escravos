#include <Arduino.h> 
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h> 
#include "functs.h"

void setup() {  
  Serial.begin(115200);
  Serial.println(); 
  Serial.println("MAC Address");
  Serial.println(WiFi.macAddress()); // Printa na Serial o endereço MAC do 
  Serial.print("ID: ");
  Serial.print(BOARD_ID);

  if(init_esp_now() == false) return;

  if(addPeer(Master_Address, CHANNEL) == false) return; 
}

void loop() { 
  vTaskDelay(10);
  int bt_ = 0;
  bt_ = digitalRead(sensorPin);
  Serial.printf("Status %d\n",bt_);
  vTaskDelay(500);
} 
