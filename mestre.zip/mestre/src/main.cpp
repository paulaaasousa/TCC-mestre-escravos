#include <Arduino.h>
#include <M5Core2.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include "functs.h"

// Variables for test data
int aleatorio = 0;
int estado = 0; // escolheu rotina
int entrada = 0;
int cont_entrada = 0;
int flag_rodadas = 0;
int flag_rotinas = 0;
unsigned long startTime = 0;
bool buttonPressed = false;
unsigned long buttonPressTime = 0; // Tempo de início da contagem
unsigned long elapsedTime = 0;     // Tempo decorrido
int responseReceived = 0;
int rotina;

esp_err_t result;

void reset(void)
{
  estado = 0;
  entrada = 0;
  cont_entrada = 0;
  flag_rodadas = 0;
  flag_rotinas = 0;
  startTime = 0;
  buttonPressed = false;
  buttonPressTime = 0; // Tempo de início da contagem
  elapsedTime = 0;     // Tempo decorrido
  responseReceived = false;
}

void setup()
{
  M5.begin();
  if (init_esp_now() == false)
    return;
  if (addPeer(Slave_Address_1, CHANNEL) == false)
    return; // Adiciona os endereços e crasha o programa se não conseguir adicionar
  if (addPeer(Slave_Address_2, CHANNEL) == false)
    return;
  if (addPeer(Slave_Address_3, CHANNEL) == false)
    return;
  if (addPeer(Slave_Address_4, CHANNEL) == false)
    return;
}

void rotina1(void)
{
  int percorre = 0;
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      if (percorre == 1)
      {
        myData.id = 1;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 2)
      {
        myData.id = 2;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 3)
      {
        myData.id = 3;
        myData.rotina = 0;
        vTaskDelay(200);
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 4)
      {
        myData.id = 4;
        myData.rotina = 0;
        vTaskDelay(200);
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void rotina2(void)
{
  int percorre = 0;
  int a = 0;
  int aleatorio = 0;
  Serial.println("comecei");
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      aleatorio = random(1, 5);
      if (cont_entrada != 0)
      {
        while (a == aleatorio)
          aleatorio = random(1, 5);
      }
      a = aleatorio;
      if (a == 1)
      {
        myData.id = 1;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 2)
      {
        myData.id = 2;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 3)
      {
        myData.id = 3;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(100);
      }
      else if (a == 4)
      {
        myData.id = 4;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void rotina3(void)
{
  int percorre = 0;
  if (rotina == 1)
  {
    myData.rotina = 1;
  }
  else if (rotina == 2)
  {
    myData.rotina = 2;
  }
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      if (percorre == 1)
      {
        myData.id = 1;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 2)
      {
        myData.id = 2;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 3)
      {
        myData.id = 3;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 4)
      {
        myData.id = 4;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
      Serial.println(cont_entrada);
    }
  }
}

void rotina4(void)
{
  int a = 0;
  int aleatorio = 0;
  if (rotina == 1)
  {
    myData.rotina = 1;
  }
  else if (rotina == 2)
  {
    myData.rotina = 2;
  }
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      aleatorio = random(1, 5);
      if (cont_entrada != 0)
      {
        while (a == aleatorio)
          aleatorio = random(1, 5);
      }
      a = aleatorio;
      if (a == 1)
      {
        myData.id = 1;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 2)
      {
        myData.id = 2;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 3)
      {
        myData.id = 3;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 4)
      {
        myData.id = 4;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void start_count()
{
  buttonPressTime = millis();
}
void end_count()
{
  elapsedTime = millis() - buttonPressTime;

  // Exibe o tempo decorrido em segundos
  Serial.println("Tempo decorrido: ");
  Serial.print(elapsedTime / 1000);
  Serial.print(".");
  Serial.print((elapsedTime % 1000) / 100); // Exibe a primeira casa decimal
  Serial.print((elapsedTime % 100) / 10);   // Exibe a segunda casa decimal
  Serial.print((elapsedTime % 10));         // Exibe a terceira casa decimal
  Serial.println(" segundos");
}

void selecionaRotina(void)
{
  int i = 1;
  flag_rodadas = 1;
  M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
  M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
  M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
  M5.Lcd.setTextSize(2);          // Define o tamanho do texto
  M5.Lcd.println("TESTE DE AGILIDADE");
  M5.Lcd.setCursor(70, 150); // Define a posição do cursor para a opção de Rotina 1
  M5.Lcd.print("Escolha a Rotina:");
  M5.Lcd.setCursor(121, 190); // Define a posição do cursor para a opção de Rotina 1
  M5.Lcd.print("Rotina ");
  M5.Lcd.print(i);
  while (flag_rotinas == 0)
  {
    M5.update();
    if (M5.BtnA.wasPressed())
    {
      i--;
      if (i == 0)
      {
        i = 1;
      }
      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(70, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha a Rotina:");
      M5.Lcd.setCursor(121, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Rotina ");
      M5.Lcd.print(i);
    }
    if (M5.BtnC.wasPressed())
    {
      i++;
      if (i == 5)
      {
        i = 4;
      }

      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(70, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha a Rotina:");
      M5.Lcd.setCursor(121, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Rotina ");
      M5.Lcd.print(i);
    }
    if (M5.BtnB.wasPressed())
    {
      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(70, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha a Rotina:");
      M5.Lcd.setCursor(121, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.setTextColor(TFT_GREEN);
      M5.Lcd.print("Rotina ");
      M5.Lcd.print(i);
      vTaskDelay(600);
      if (i == 1)
      {
        rotina = 0;
        start_count();
        rotina1();
        end_count();
      }
      if (i == 2)
      {
        rotina = 0;
        start_count();
        Serial.println(i);
        Serial.println("começar rot 2");
        rotina2();
        Serial.println("terminei rot 2");
        end_count();
      }
      if (i == 3)
      {
        rotina = 1;
        start_count();
        rotina3();
        end_count();
      }
      if (i == 4)
      {
        rotina = 1;
        start_count();
        rotina4();
        end_count();
      }
    }
  }
}
void repeticoes(void)
{
  int i = 1, rodadas = 0;
  M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
  M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
  M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
  M5.Lcd.setTextSize(2);          // Define o tamanho do texto
  M5.Lcd.println("TESTE DE AGILIDADE");
  M5.Lcd.setCursor(10, 150); // Define a posição do cursor para a opção de Rotina 1
  M5.Lcd.print("Escolha o num de rodadas:");
  M5.Lcd.setCursor(160, 190); // Define a posição do cursor para a opção de Rotina 1
  M5.Lcd.print(i);
  while (flag_rodadas == 0)
  {
    M5.update();
    if (M5.BtnA.wasPressed())
    {
      i--;
      if (i == 0)
      {
        i = 1;
      }
      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(10, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha o num de rodadas:");
      M5.Lcd.setCursor(160, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print(i);
    }
    if (M5.BtnC.wasPressed())
    {
      i++;
      if (i == 101)
      {
        i = 100;
      }
      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(10, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha o num de rodadas:");
      M5.Lcd.setCursor(160, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print(i);
    }
    if (M5.BtnB.wasPressed())
    {
      M5.Lcd.fillScreen(TFT_BLACK);   // Preenche a tela com preto
      M5.Lcd.setCursor(50, 80);       // Define a posição do cursor de texto
      M5.Lcd.setTextColor(TFT_WHITE); // Define a cor do texto como branco
      M5.Lcd.setTextSize(2);          // Define o tamanho do texto
      M5.Lcd.println("TESTE DE AGILIDADE");
      M5.Lcd.setCursor(10, 150); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.print("Escolha o num de rodadas:");
      M5.Lcd.setCursor(160, 190); // Define a posição do cursor para a opção de Rotina 1
      M5.Lcd.setTextColor(TFT_GREEN);
      M5.Lcd.print(i);
      vTaskDelay(600);
      rodadas=i; v vf
      entrada = rodadas;
      entrada = entrada * 4;
      Serial.println(entrada);
      selecionaRotina();
    }
  }
}

// Para realizar os envios, seguir está estrutura que desenhei
void loop()
{
  M5.update();
  reset();
  vTaskDelay(200);
  repeticoes();
  selecionaRotina();
}
