#pragma once
#include <Arduino.h> 
#include <M5Core2.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h> 


// Set your Board and Server ID 
#define BOARD_ID 0
#define CHANNEL 5  // Canal do Wifi usado para enviar a mensagem

// Lista de endereços Max
uint8_t My_Address[] = {0x40,0xF5,0x20,0x82,0xB5,0x58};
uint8_t Slave_Address_1[] = {0xA4,0xE5,0x7C,0x47,0x48,0xAC}; //roxinho
uint8_t Slave_Address_2[] = {0xA4,0xE5,0x7C,0x47,0x15,0x94}; //amarelinh0
uint8_t Slave_Address_3[] = {0x08,0x3A,0xF2,0xAB,0x4D,0x8C}; //roxão
uint8_t Slave_Address_4[] = {0x40, 0xF5, 0x20, 0x82, 0xB5, 0x58}; //Macaquinho


// Strutura para envio das mensagens 
// Aqui pode adicionar mais variaveis até 240 bytes
// Necessariamente precisa ter uma struct identica no mestre e no escravo para comunicação
typedef struct message_ { 
  uint8_t id = 0xFF;
  int Status_Led = 0;
  int rotina = 0;
} message_;
message_ myData;  

int recebido = 0;

bool addPeer(const uint8_t * mac_addr, uint8_t chan); 
void printMAC(const uint8_t * mac_addr);
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status);
void OnDataRecv(const uint8_t * mac_addr, const uint8_t *incomingData, int len);
bool init_esp_now();

// Função usada para adicionar os Mestre/Slaves
// Retorna True se deu boa e falso caso contrário
bool addPeer(const uint8_t * mac_addr, uint8_t chan){
  esp_now_peer_info_t peer;
  esp_now_del_peer(mac_addr);
  memset(&peer, 0, sizeof(esp_now_peer_info_t));
  peer.channel = chan;
  peer.encrypt = false;
  memcpy(peer.peer_addr, mac_addr, sizeof(uint8_t[6]));
  if (esp_now_add_peer(&peer) != ESP_OK){
    Serial.print("Failed to add peer: ");
    printMAC(mac_addr);
    return false;
  }
  return true;
}

// Bem..... isso da print no Mac..... meio óbvio
void printMAC(const uint8_t * mac_addr){
  char macStr[18];
  snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x",
           mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
  Serial.print(macStr);
}

//Call Back do envio da mensagem
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
}

//Call Back da recepção da mensagem
void OnDataRecv(const uint8_t * mac_addr, const uint8_t *incomingData, int len) { 
  Serial.print("Packet received from: ");
  printMAC(mac_addr);
  Serial.println();
  Serial.print("data size = ");
  Serial.print(sizeof(incomingData));
  Serial.print(", len = ");
  Serial.println(len);
  memcpy(&myData, incomingData, sizeof(myData)); 
  Serial.println(" ");
  Serial.printf("ID: %d, LED: %d /n", myData.id, myData.Status_Led); // Atuar no Led utilizando está variavel myData.Status_Led
  recebido = myData.Status_Led;
}

// Iniciar o Esp Now
bool init_esp_now()
{
  WiFi.mode(WIFI_STA);  

  // set WiFi channel   
  ESP_ERROR_CHECK(esp_wifi_set_channel(CHANNEL,  WIFI_SECOND_CHAN_NONE));
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return false;
  }

  // set callback routines
  esp_now_register_send_cb(OnDataSent);
  esp_now_register_recv_cb(OnDataRecv);
  return true;
}