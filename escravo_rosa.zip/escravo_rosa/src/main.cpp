#include <Arduino.h> 
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h> 
#include "functs.h"


int button_status;

void setup() {  
  Serial.begin(115200);
  Serial.println(); 
  Serial.println("MAC Address");
  Serial.println(WiFi.macAddress()); // Printa na Serial o endereço MAC do 
  Serial.print("ID: ");
  Serial.print(BOARD_ID);
  if(init_esp_now() == false) return;

  if(addPeer(Master_Address, CHANNEL) == false) return; 
}

void loop() { 
  vTaskDelay(10);
  int bt = 0;
  bt = digitalRead(sensorPin);
  Serial.printf("Status %d\n",bt);
  vTaskDelay(500);
} 
